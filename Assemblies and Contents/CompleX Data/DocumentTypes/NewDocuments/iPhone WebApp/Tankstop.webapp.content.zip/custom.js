﻿
//Definition einer globalen Variable für die Referenz für die Datenbank
var db;
// statusBar: 'black-translucent'
 //Konstruktor für jQTouch
var jQT = $.jQTouch({
	  icon:'myIcon.png',
    statusBar: 'black'
});

//Überschreiben der Action Methode des Formulars
$(document).ready(function () {
    $('#createEntry form').submit(createEntry);
    $('#settings form').submit(storeSettings);
    $('#settings').bind('pageAnimationStart', loadSettings);

    var shortName = 'Fuelstop';
    var version = '1.0'; //Versionsnummer
    var displayName = 'Fuelstop';
    var maxSize = 65536; 
    db = openDatabase(shortName, version, displayName, maxSize);
    db.transaction(
    function (transaction) {
        transaction.executeSql(
        'CREATE TABLE IF NOT EXISTS fuelstops ' +
        '  (id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, ' +
        '  date DATE NOT NULL, currentkm INTEGER NOT NULL, ' +
        '  amount INTEGER NOT NULL );'
        );
    }
    );

    refreshEntries();
});

//Datensätze einfügen
function createEntry() {
    //Formulardaten in lokalen Variablen zwischenspeichern
    var date = $('#date').val(); 
    var currentkm = $('#currentkm').val(); 
    var amount = $('#amount').val(); 
    db.transaction(
        function (transaction) {
            transaction.executeSql(
            'INSERT INTO fuelstops (date, currentkm, amount) VALUES (?, ?, ?);', [date, currentkm, amount],
            function () {
                refreshEntries();
                jQT.goBack();
            },
            errorHandler
            );
            }
        );
    return false;
}

//Datensätze auslesen
function refreshEntries() {
    //Löschen aller li Elemente, deren Index größer ist als 0, um zu verhindern, dass Datensätze zweifach eingefügt werden
    $('#overview ul li:gt(0)').remove();
    db.transaction(
        function (transaction) {
            transaction.executeSql(
            'SELECT * FROM fuelstops ORDER BY date;', [],
                function (transaction, result) {
                    for (var i = 0; i < result.rows.length; i++) {
                        var row = result.rows.item(i);
                        var newEntryRow = $('#entryTemplate').clone();
                        //Nach dem clonen des li Elements wird die id und das style mit display none entfernt
                        newEntryRow.removeAttr('id');
                        newEntryRow.removeAttr('style');
                        newEntryRow.data('entryId', row.id);
                        //Inhalte einfügen
                        newEntryRow.appendTo('#overview ul');
                        newEntryRow.find('.tempdate').text(row.date);
                        newEntryRow.find('.tempcurrentkm').text(row.currentkm);
                        newEntryRow.find('.tempamount').text(row.amount);
                    }
                },
                errorHandler
            );
        }
    );
}

//Initialisieren der Einstellungen
function loadSettings() {
    $('#make').val(localStorage.make);
    $('#type').val(localStorage.type);
    $('#badge').val(localStorage.badge);
}

//Speichern der Einstellungen im LocalStorage-Objekt
function storeSettings() {
    localStorage.make = $('#make').val();
    localStorage.type = $('#type').val();
    localStorage.badge = $('#badge').val();
    jQT.goBack();
    return false;
}

//Error handler
function errorHandler(transaction, error) {
    alert('An Error occured. The error was ' + error.message + ' (Code ' + error.code + ')');
    return true;
}

